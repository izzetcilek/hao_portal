import os
import sqlite3
import re
from datetime import datetime, time
from dateutil import tz
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, send_from_directory, abort, session
import pandas as pd

# =========================
# Settings
# =========================
BASE_DIR   = os.path.dirname(__file__)
DATA_DIR   = os.path.join(BASE_DIR, "data")
DB_PATH    = os.path.join(DATA_DIR, "school.db")
ANN_PATH   = os.path.join(DATA_DIR, "announcements.json")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
LAST_META   = os.path.join(DATA_DIR, "last_upload.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)

TZ_IST = tz.gettz("Europe/Istanbul")
ALLOWED_EXTS   = {".xlsx", ".csv"}
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "hao123")
SECRET_KEY     = os.environ.get("SECRET_KEY", "change-me")

BELL_SLOTS = [
    (1, "08:50", "09:30"),
    (2, "09:50", "10:30"),
    (3, "10:45", "11:25"),
    (4, "11:40", "12:20"),
    (5, "12:35", "13:15"),
    (6, "14:15", "14:55"),
    (7, "15:10", "15:50"),
]

app = Flask(__name__)
app.secret_key = SECRET_KEY

# =========================
# DB helpers
# =========================
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT,
            full_name  TEXT,
            mother_phone TEXT,
            father_phone TEXT,
            mother_status TEXT,
            father_status TEXT,
            divorced TEXT,
            health_note TEXT,
            student_phone TEXT,
            notes TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS class_schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT,
            weekday INTEGER,
            lesson_no INTEGER,
            subject TEXT,
            teacher TEXT,
            room TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS teacher_schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher TEXT,
            weekday INTEGER,
            lesson_no INTEGER,
            subject TEXT,
            class_name TEXT,
            room TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS subject_alias (
            code TEXT PRIMARY KEY,
            full_name TEXT NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS teacher_alias (
            code TEXT PRIMARY KEY,
            full_name TEXT NOT NULL
        )
    """)
    conn.commit(); conn.close()

def clear_tables(conn):
    cur = conn.cursor()
    cur.execute("DELETE FROM students")
    cur.execute("DELETE FROM class_schedule")
    cur.execute("DELETE FROM teacher_schedule")
    conn.commit()

def _normalize_header(h: str) -> str:
    if h is None: return ""
    return (str(h).strip().lower()
            .replace("ı","i").replace("ğ","g").replace("ş","s")
            .replace("ü","u").replace("ö","o").replace("ç","c"))

# ---- session / admin ----
def _is_admin(data=None):
    try:
        if session.get("is_admin"): return True
        pw = (data or {}).get("password", "")
        return pw == ADMIN_PASSWORD
    except Exception:
        return False

@app.route("/api/admin/login", methods=["POST"])
def api_admin_login():
    data = request.get_json(force=True, silent=True) or {}
    if _is_admin(data):
        session["is_admin"] = True
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "wrong_password"}), 403

# ---- phone utils ----
def _clean_phone(p):
    if p is None: return ""
    s = re.sub(r"\D+", "", str(p))
    if not s: return ""
    if s.startswith("90") and len(s) in (12, 13): s = s[2:]
    if len(s) == 10: s = "0" + s
    if len(s) == 11 and not s.startswith("0"): s = "0" + s[-10:]
    return s

HEADER_MAP_STUDENTS = {
    "sinif":"class_name", "sinif adi":"class_name","sınıf":"class_name","sinif_adi":"class_name",
    "ad soyad":"full_name","adi soyadi":"full_name","isim":"full_name","ad":"full_name","ogrenci":"full_name",
    "anne tel":"mother_phone","anne telefon":"mother_phone","anne numara":"mother_phone",
    "baba tel":"father_phone","baba telefon":"father_phone","baba numara":"father_phone",
    "anne durum":"mother_status","anne saglik":"mother_status",
    "baba durum":"father_status","baba saglik":"father_status",
    "bosanma":"divorced","boşanma":"divorced",
    "saglik":"health_note","saglik notu":"health_note","ogrenci saglik":"health_note","saglik_durumu":"health_note",
    "ogrenci tel":"student_phone","ogrenci telefon":"student_phone",
    "aciklama":"notes","not":"notes","aciklamalar":"notes"
}

DAY_ALIASES = {
    1: {"pzt","pazartesi","mon","monday"},
    2: {"sal","sali","salı","tue","tuesday"},
    3: {"car","carsamba","çarşamba","wed","wednesday","çar"},
    4: {"per","persembe","perşembe","thu","thursday"},
    5: {"cum","cuma","fri","friday"},
}
def parse_weekday_name(colname):
    key = _normalize_header(colname)
    for w, names in DAY_ALIASES.items():
        if key in names: return w
    return None

TEACHER_CODE_RE = re.compile(r"^\s*(.+?)\s+([A-ZÇĞİÖŞÜ]{2,6})\s*$")
def split_subject_code(cell):
    if cell is None: return ("", "")
    s = str(cell).strip()
    if not s: return ("", "")
    m = TEACHER_CODE_RE.match(s)
    if m: return (m.group(1).strip(), m.group(2).strip())
    return (s, "")

# =========================
# Aliases API
# =========================
@app.route("/api/aliases")
def api_aliases():
    conn = get_db()
    subs = {r["code"]: r["full_name"] for r in conn.execute("SELECT code, full_name FROM subject_alias")}
    teas = {r["code"]: r["full_name"] for r in conn.execute("SELECT code, full_name FROM teacher_alias")}
    conn.close()
    return jsonify({"subjects": subs, "teachers": teas})

@app.route("/api/alias/subject", methods=["POST"])
def api_alias_subject_set():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    code = (data.get("code") or "").strip().upper()
    full = (data.get("full_name") or "").strip()
    if not code or not full: return jsonify({"ok": False, "error": "missing"}), 400
    conn = get_db()
    with conn:
        conn.execute(
            "INSERT INTO subject_alias(code, full_name) VALUES(?, ?) "
            "ON CONFLICT(code) DO UPDATE SET full_name=excluded.full_name", (code, full)
        )
    return jsonify({"ok": True})

@app.route("/api/alias/teacher", methods=["POST"])
def api_alias_teacher_set():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    code = (data.get("code") or "").strip().upper()
    full = (data.get("full_name") or "").strip()
    if not code or not full: return jsonify({"ok": False, "error": "missing"}), 400
    conn = get_db()
    with conn:
        conn.execute(
            "INSERT INTO teacher_alias(code, full_name) VALUES(?, ?) "
            "ON CONFLICT(code) DO UPDATE SET full_name=excluded.full_name", (code, full)
        )
    return jsonify({"ok": True})

# =========================
# Importer
# =========================
def import_from_file(path):
    ext = os.path.splitext(path)[1].lower()
    conn = get_db()

    def import_students(df):
        df = df.rename(columns={c: HEADER_MAP_STUDENTS.get(_normalize_header(c), c) for c in df.columns})
        needed = ["class_name","full_name","mother_phone","father_phone","mother_status","father_status","divorced","health_note","student_phone","notes"]
        for k in needed:
            if k not in df.columns: df[k] = ""
        for col in ("mother_phone","father_phone","student_phone"):
            df[col] = df[col].map(_clean_phone)
        df = df[needed].fillna("")
        df.to_sql("students", conn, if_exists="append", index=False)

    def import_class_grid(df):
        cols = {_normalize_header(c): c for c in df.columns}
        class_col  = cols.get("sinif") or cols.get("sinif adi") or cols.get("sınıf") or cols.get("class_name") or "sinif"
        lesson_col = cols.get("ders") or cols.get("ders_no") or cols.get("lesson") or "ders"
        if class_col not in df.columns or lesson_col not in df.columns:
            raise ValueError("Grid için 'sinif' ve 'ders' başlıkları zorunlu.")
        day_cols = {}
        for c in df.columns:
            w = parse_weekday_name(c)
            if w: day_cols[w] = c
        if len(day_cols) < 5:
            raise ValueError("Grid formatında 5 gün sütunu (Pzt/Sal/Çar/Per/Cum) bulunamadı.")
        rows_to_insert, teacher_rows = [], []
        for _, row in df.iterrows():
            cls = str(row[class_col]).strip()
            if not cls: continue
            try:
                ln = int(str(row[lesson_col]).strip())
            except:
                continue
            for w in range(1,6):
                cell = row.get(day_cols[w], "")
                subj, code = split_subject_code(cell)
                if not subj and not code: continue
                rows_to_insert.append((cls.replace(" ",""), w, ln, subj, code, ""))
                if code:
                    teacher_rows.append((code, w, ln, subj, cls.replace(" ",""), ""))
        with conn:
            if rows_to_insert:
                conn.executemany(
                    "INSERT INTO class_schedule (class_name, weekday, lesson_no, subject, teacher, room) VALUES (?,?,?,?,?,?)",
                    rows_to_insert
                )
            if teacher_rows:
                conn.executemany(
                    "INSERT INTO teacher_schedule (teacher, weekday, lesson_no, subject, class_name, room) VALUES (?,?,?,?,?,?)",
                    teacher_rows
                )

    if ext == ".xlsx":
        xls = pd.ExcelFile(path)
        frames = {_normalize_header(n): xls.parse(n) for n in xls.sheet_names}
        if "ogrenciler"  in frames: import_students(frames["ogrenciler"])
        if "sinif_grid"  in frames: import_class_grid(frames["sinif_grid"])
    elif ext == ".csv":
        fname = os.path.basename(path).lower()
        df = pd.read_csv(path)
        ncols = [_normalize_header(c) for c in df.columns]
        has_days = sum(1 for c in df.columns if parse_weekday_name(c))
        if "ogrenci" in fname:
            import_students(df)
        elif has_days >= 5 and (("sinif" in ncols) or ("sınıf" in ncols)) and (("ders" in ncols) or ("ders_no" in ncols) or ("lesson" in ncols)):
            import_class_grid(df)
        else:
            raise ValueError("CSV grid algılanamadı. 'sinif' + 'ders' + gün sütunları olmalı.")
    else:
        raise ValueError("Sadece .xlsx ve .csv desteklenir")

    conn.close()

# =========================
# Time & JSON utils
# =========================
def now_istanbul():
    return datetime.now(TZ_IST)

def is_now_lesson(lesson_no, dt):
    for ln, s, e in BELL_SLOTS:
        if ln == lesson_no:
            try:
                t1 = time.fromisoformat(s); t2 = time.fromisoformat(e)
                return t1 <= dt.time() <= t2
            except Exception:
                return False
    return False

def json_load(path):
    import json
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def json_dump(path, data):
    import json
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
def _schedule_counts():
    conn = get_db()
    a = conn.execute("SELECT COUNT(*) FROM class_schedule").fetchone()[0]
    b = conn.execute("SELECT COUNT(*) FROM teacher_schedule").fetchone()[0]
    conn.close()
    return a, b

def reimport_last(clear_first: bool=False):
    """last_upload.json'da kayıtlı dosyayı tekrar içe aktar."""
    if not os.path.exists(LAST_META):
        raise RuntimeError("Kayıtlı yükleme bulunamadı.")
    meta = json_load(LAST_META)
    path = meta.get("path")
    if not path or not os.path.exists(path):
        raise RuntimeError("Son dosya yolu erişilemiyor.")
    if clear_first:
        conn = get_db()
        clear_tables(conn)
        conn.close()
    import_from_file(path)
    return path
@app.route("/api/admin/reimport", methods=["POST"])
def api_admin_reimport():
    data = request.get_json(force=True, silent=True) or {}
    if (data.get("password") or "") != ADMIN_PASSWORD:
        return jsonify({"ok": False, "error": "unauthorized"}), 403
    clear_first = bool(data.get("clear_first"))
    try:
        p = reimport_last(clear_first=clear_first)
        return jsonify({"ok": True, "path": p})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

# =========================
# Pages
# =========================
@app.route("/")
def home():
    anns = []
    if os.path.exists(ANN_PATH):
        try:
            anns = [a for a in json_load(ANN_PATH) if a.get("text")]
        except Exception:
            pass
    return render_template("index.html", announcements=anns)

@app.route("/classes")
def classes_page():  return render_template("classes.html")

@app.route("/teachers")
def teachers_page(): return render_template("teachers.html")

@app.route("/phonebook")
def phonebook_page(): return render_template("phonebook.html")

# =========================
# APIs
# =========================
@app.route("/api/classes")
def api_classes():
    conn = get_db()
    rows = conn.execute("SELECT DISTINCT class_name FROM class_schedule WHERE class_name <> '' ORDER BY class_name").fetchall()
    if not rows:
        rows = conn.execute("SELECT DISTINCT class_name FROM students WHERE class_name <> '' ORDER BY class_name").fetchall()
    conn.close()
    return jsonify([r["class_name"] for r in rows])

@app.route("/api/teachers")
def api_teachers():
    conn = get_db()
    rows = conn.execute("SELECT DISTINCT teacher FROM teacher_schedule WHERE teacher <> '' ORDER BY teacher").fetchall()
    conn.close()
    return jsonify([r["teacher"] for r in rows])

@app.route("/api/students")
def api_students():
    class_name = request.args.get("class")
    q = request.args.get("q","").strip().lower()
    conn = get_db()
    cur = conn.cursor()
    if class_name:
        rows = cur.execute("SELECT * FROM students WHERE class_name = ? ORDER BY full_name", (class_name,)).fetchall()
    else:
        rows = cur.execute("SELECT * FROM students ORDER BY class_name, full_name").fetchall()
    conn.close()
    items = [dict(r) for r in rows]
    for it in items:
        for k in ("mother_phone","father_phone","student_phone"):
            it[k] = _clean_phone(it.get(k, ""))
    if q:
        items = [s for s in items if q in s["full_name"].lower()]
    return jsonify(items)

@app.route("/api/schedule/class/<class_name>")
def api_schedule_class(class_name):
    conn = get_db()
    rows = conn.execute("""
        SELECT weekday, lesson_no, subject, teacher, room
        FROM class_schedule WHERE class_name = ? ORDER BY weekday, lesson_no
    """,(class_name,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/schedule/teacher/<teacher>")
def api_schedule_teacher(teacher):
    conn = get_db()
    rows = conn.execute("""
        SELECT weekday, lesson_no, subject, class_name, room
        FROM teacher_schedule WHERE teacher = ? ORDER BY weekday, lesson_no
    """,(teacher,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/bells")
def api_bells():
    return jsonify([{"lesson_no": ln, "start": s, "end": e} for (ln,s,e) in BELL_SLOTS])

@app.route("/api/now")
def api_now():
    dt = now_istanbul()
    return jsonify({"iso": dt.isoformat(), "weekday": dt.isoweekday(), "time": dt.strftime("%H:%M")})

# ---------- STUDENT CRUD ----------
@app.route("/api/student/create", methods=["POST"])
def api_student_create():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    allowed = ["class_name","full_name","mother_phone","father_phone","mother_status","father_status","divorced","health_note","student_phone","notes"]
    vals = {k: data.get(k, "") for k in allowed}
    for k in ("mother_phone","father_phone","student_phone"):
        vals[k] = _clean_phone(vals.get(k))
    conn = get_db()
    with conn:
        cur = conn.execute("""
            INSERT INTO students (class_name, full_name, mother_phone, father_phone, mother_status, father_status, divorced, health_note, student_phone, notes)
            VALUES (:class_name, :full_name, :mother_phone, :father_phone, :mother_status, :father_status, :divorced, :health_note, :student_phone, :notes)
        """, vals)
        vals["id"] = cur.lastrowid
    return jsonify({"ok": True, "item": vals})

@app.route("/api/student/update", methods=["POST"])
def api_student_update():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    sid = data.get("id")
    if not sid: return jsonify({"ok": False, "error": "missing id"}), 400
    allowed = ["class_name","full_name","mother_phone","father_phone","mother_status","father_status","divorced","health_note","student_phone","notes"]
    updates = {k: data.get(k) for k in allowed if k in data}
    for k in ("mother_phone","father_phone","student_phone"):
        if k in updates: updates[k] = _clean_phone(updates[k])
    if not updates: return jsonify({"ok": False, "error": "no fields"}), 400
    sets = ", ".join([f"{k} = ?" for k in updates.keys()])
    vals = list(updates.values()) + [sid]
    conn = get_db()
    with conn:
        conn.execute(f"UPDATE students SET {sets} WHERE id = ?", vals)
    return jsonify({"ok": True})

@app.route("/api/student/delete", methods=["POST"])
def api_student_delete():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    sid = data.get("id")
    if not sid: return jsonify({"ok": False, "error": "missing id"}), 400
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM students WHERE id = ?", (sid,))
    return jsonify({"ok": True})


# =========================
# Admin & Announcements
@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        password = request.form.get("password","")
        if password != ADMIN_PASSWORD:
            flash("Şifre hatalı", "error")
            return redirect(url_for("admin"))

        f = request.files.get("file")
        if not f or f.filename == "":
            flash("Dosya seçiniz", "error")
            return redirect(url_for("admin"))

        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in ALLOWED_EXTS:
            flash("Sadece .xlsx ve .csv dosyaları", "error")
            return redirect(url_for("admin"))

        # seçenek: önce temizle
        clear_first = (request.form.get("clear_first") == "on")

        # dosyayı arşive kaydet
        ts  = datetime.now().strftime("%Y%m%d-%H%M%S")
        dst = os.path.join(UPLOADS_DIR, f"upload-{ts}{ext}")
        f.save(dst)

        try:
            if clear_first:
                conn = get_db()
                clear_tables(conn)
                conn.close()

            import_from_file(dst)
            # meta yaz
            json_dump(LAST_META, {"path": dst, "time": ts, "ext": ext})
            flash("İçe aktarma başarılı ✅", "ok")
        except Exception as e:
            flash(f"Hata: {e}", "error")

        return redirect(url_for("admin"))

    return render_template("admin.html")


@app.route("/data/announcements.json", methods=["GET", "POST"])
def ann_json():
    if request.method == "POST":
        jd = request.get_json(force=True, silent=True) or {}
        pw   = jd.get("password", "")
        data = jd.get("data", [])
        if pw != ADMIN_PASSWORD: abort(403)
        if not isinstance(data, list):
            return jsonify({"ok": False, "error": "bad_format"}), 400
        json_dump(ANN_PATH, data)
        return jsonify({"ok": True})
    else:
        if not os.path.exists(ANN_PATH):
            json_dump(ANN_PATH, [{"text":"Hacı Ahmet Özsoy Ortaokulu Akıllı Asistanına Hoş Geldiniz!", "link": ""}])
        return send_from_directory(os.path.dirname(ANN_PATH), os.path.basename(ANN_PATH))
# ========= Yeni: tüm kısaltmaları listele =========
@app.route("/api/aliases/full")
def api_aliases_full():
    conn = get_db()
    # Mevcut sözlükler
    sub_map = {r["code"]: r["full_name"] for r in conn.execute("SELECT code, full_name FROM subject_alias")}
    tea_map = {r["code"]: r["full_name"] for r in conn.execute("SELECT code, full_name FROM teacher_alias")}

    # Programdan tespit edilenler (boşları at)
    subjects = set()
    for r in conn.execute("SELECT DISTINCT subject FROM class_schedule WHERE subject <> ''"):
        subjects.add((r["subject"] or "").strip())

    teachers = set()
    for r in conn.execute("SELECT DISTINCT teacher FROM teacher_schedule WHERE teacher <> ''"):
        teachers.add((r["teacher"] or "").strip().upper())
    for r in conn.execute("SELECT DISTINCT teacher FROM class_schedule WHERE teacher <> ''"):
        teachers.add((r["teacher"] or "").strip().upper())

    conn.close()

    # Liste halinde döndür (sıralı)
    return jsonify({
        "subjects_detected": sorted([s for s in subjects if s]),
        "teachers_detected": sorted([t for t in teachers if t]),
        "subjects": sub_map,
        "teachers": tea_map
    })

# ========= Yeni: ders sözlüğünü toplu kaydet =========
@app.route("/api/aliases/subject/bulk", methods=["POST"])
def api_aliases_subject_bulk():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    items = data.get("items") or {}
    if not isinstance(items, dict): return jsonify({"ok": False, "error": "bad_format"}), 400
    conn = get_db()
    with conn:
        for code, full in items.items():
            code = (code or "").strip()
            full = (full or "").strip()
            if not code or not full: continue
            conn.execute(
                "INSERT INTO subject_alias(code, full_name) VALUES(?, ?) "
                "ON CONFLICT(code) DO UPDATE SET full_name=excluded.full_name",
                (code, full)
            )
    return jsonify({"ok": True})

# ========= Yeni: öğretmen sözlüğünü toplu kaydet =========
@app.route("/api/aliases/teacher/bulk", methods=["POST"])
def api_aliases_teacher_bulk():
    data = request.get_json(force=True, silent=True) or {}
    if not _is_admin(data): return jsonify({"ok": False, "error": "unauthorized"}), 403
    items = data.get("items") or {}
    if not isinstance(items, dict): return jsonify({"ok": False, "error": "bad_format"}), 400
    conn = get_db()
    with conn:
        for code, full in items.items():
            code = (code or "").strip().upper()
            full = (full or "").strip()
            if not code or not full: continue
            conn.execute(
                "INSERT INTO teacher_alias(code, full_name) VALUES(?, ?) "
                "ON CONFLICT(code) DO UPDATE SET full_name=excluded.full_name",
                (code, full)
            )
    return jsonify({"ok": True})

# Diagnose
@app.route("/__routes__")
def __routes__():
    return "<pre>" + "\n".join(sorted([f"{sorted(r.methods)}  {r.rule}" for r in app.url_map.iter_rules()])) + "</pre>"

# =========================
# Boot
# =========================
init_db()
try:
    cs, ts = _schedule_counts()
    if (cs == 0 and ts == 0) and os.path.exists(LAST_META):
        meta = json_load(LAST_META)
        p = meta.get("path")
        if p and os.path.exists(p):
            import_from_file(p)
            print(f"[AUTO] Son yükleme yeniden içe aktarıldı: {p}")
except Exception as e:
    print("[AUTO REIMPORT SKIPPED]", e)

if __name__ == "__main__":
    app.run(debug=True)
