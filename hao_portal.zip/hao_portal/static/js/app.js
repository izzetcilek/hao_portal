// Kaydet
detail.querySelector(".saveEdit").addEventListener("click", async ()=>{
  if(!(await ensureAdmin())) return;
  const body = {
    id: st.id,
    full_name: detail.querySelector(".e_full_name").value.trim(),
    class_name: detail.querySelector(".e_class_name").value.trim(),
    mother_phone: normalizeTR(detail.querySelector(".e_mother_phone").value),
    father_phone: normalizeTR(detail.querySelector(".e_father_phone").value),
    student_phone: normalizeTR(detail.querySelector(".e_student_phone").value),
    mother_status: detail.querySelector(".e_mother_status").value.trim(),
    father_status: detail.querySelector(".e_father_status").value.trim(),
    divorced: detail.querySelector(".e_divorced").value.trim(),
    health_note: detail.querySelector(".e_health_note").value.trim(),
    notes: detail.querySelector(".e_notes").value.trim(),
  };
  const res = await fetch("/api/student/update",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    credentials:"same-origin",
    body:JSON.stringify(body)
  });
  if(res.ok){ alert("Kaydedildi."); load(); } else { const j=await res.json().catch(()=>({})); alert("Hata: "+(j.error||res.status)); }
});

// Sil
detail.querySelector(".delBtn").addEventListener("click", async ()=>{
  if(!confirm("Bu öğrenciyi silmek istiyor musunuz?")) return;
  if(!(await ensureAdmin())) return;
  const res = await fetch("/api/student/delete",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    credentials:"same-origin",
    body:JSON.stringify({id: st.id})
  });
  if(res.ok){ currentOpen=null; load(); } else { const j=await res.json().catch(()=>({})); alert("Hata: "+(j.error||res.status)); }
});

// Yeni ekle
document.getElementById("saveAdd").addEventListener("click", async ()=>{
  if(!(await ensureAdmin())) return;
  const val = sel => document.querySelector(sel).value.trim();
  const payload = {
    full_name: val(".a_full"),
    class_name: val(".a_class"),
    student_phone: normalizeTR(val(".a_stu")),
    mother_phone:  normalizeTR(val(".a_mom")),
    father_phone:  normalizeTR(val(".a_dad")),
    divorced: val(".a_div"),
    mother_status: val(".a_ms"),
    father_status: val(".a_fs"),
    health_note: val(".a_health"),
    notes: val(".a_notes"),
  };
  const res = await fetch("/api/student/create",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    credentials:"same-origin",
    body:JSON.stringify(payload)
  });
  const j = await res.json().catch(()=>({}));
  if(res.ok && j.ok){
    alert("Eklendi.");
    document.getElementById("addForm").classList.add("hidden");
    document.querySelectorAll("#addForm input").forEach(i=> i.value="");
    load();
  } else {
    alert("Hata: " + (j.error || res.status));
  }
});

async function ensureAdmin(){
  if (window.__isAdmin) return true;
  const pw = await askPassword();
  if (!pw) return false;

  const r = await fetch("/api/admin/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: JSON.stringify({ password: pw })
  });

  if (r.ok) { window.__isAdmin = true; return true; }
  const j = await r.json().catch(()=>({}));
  alert("Hata: " + (j.error || r.status));
  return false;
}
